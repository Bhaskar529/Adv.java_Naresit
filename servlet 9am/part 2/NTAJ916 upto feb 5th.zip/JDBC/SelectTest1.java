//SelectTest1.java

import java.sql.*;
import java.util.*;

public class SelectTest1
{
	public static void main(String[] args) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter student address:");
		 String addrs=sc.next(); //gives   hyd
		 //convert input value as required for  the SQL Query
		    addrs="'"+addrs+"'";  //gives 'hyd'

			//  Load jdbc driver (optional)
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//Establish the connection
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
				                                                                                                                     "System","manager");
			  // create JDBC Statement obj
			   Statement st=con.createStatement();

			   //prepare SQL query
			               // SELECT * FROM STUDENT WHERE SADD='hyd'
			    String query="SELECT * FROM STUDENT WHERE SADD="+addrs;
				  System.out.println(query);

				  //send and execute the SQL Query in Db s/w
				  ResultSet rs=st.executeQuery(query);


				  //process the ResultSet obj
				  boolean isRsEmpty=false;
				  while(rs.next()){
                      System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getFloat(4));
					 isRsEmpty=true;
				  }
				 
				 if(isRsEmpty)
				   System.out.println(" records are found and displayed");
				  else
					  System.out.println("no records are found");
				  
					 


				  //close the jdbc objs
				   rs.close();
				   st.close();
				   con.close();

	}//main
}//class
// cmd> javac    SelectTest1.java
//cmd> java SelectTest1
