//SelectTest.java

 import java.sql.*;

public class SelectTest
{
	public static void main(String[] args)  throws Exception
	{
		  //Load jdbc driver class
		    Class.forName("oracle.jdbc.driver.OracleDriver");
		  //establish the connection
		    Connection con=
				  DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
			//create JDBC Statement obj
			Statement st=con.createStatement();
			//Send and execute the SELECT SQL Query to DB s/w
			ResultSet rs=st.executeQuery("SELECT * FROM STUDENT");
			//process the ResultSet obj
			while(rs.next()!=false){
				// System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getFloat(4));
				// System.out.println(rs.getInt("SNO")+"  "+rs.getString("SNAME")+"  "+rs.getString("SADD")+"  "+rs.getFloat("AVG"));
				 System.out.println(rs.getString("SNO")+"  "+rs.getString("SNAME")+"  "+rs.getString("SADD")+"  "+rs.getString("AVG"));
			}
			//close jdbc objs
			   rs.close();
			   st.close();
			   con.close();

	}//main
}//class
