//ConnTest.java
  import java.sql.*;  //jdbc api

public class ConnTest
{
	public static void main(String args[])throws Exception{
		     
			  //Load the jdbc driver class
			   Class.forName("oracle.jdbc.driver.OracleDriver");
              
		     //Establish  the Connection with   Oracle Db s/w
                        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", 
							                                                                                                                       "system","manager");
				// create Statement obj
				Statement st=con.createStatement();
				System.out.println("statement obj class name ::"+st.getClass());
			  //  check wheather the JDBC con is established  or not
	             if(con==null)
					  System.out.println("Connection is not Established");
				 else 
					 System.out.println("Connection is  Established");

				 System.out.println("The JDBC con object class name ::"+con.getClass());
			
	
	}
}