//SelectTest2.java

import java.sql.*;
import java.util.*;

public class SelectTest2
{
	public static void main(String[] args) throws Exception
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee  start salary range:");
		 float startSal=sc.nextFloat();  //give 1000
		 System.out.println("Enter employee  end salary range:");
		 float endSal=sc.nextFloat();  //gives 2000
		
		

			//  Load jdbc driver (optional)
			Class.forName("oracle.jdbc.driver.OracleDriver");

			//Establish the connection
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
				                                                                                                                     "System","manager");
			  // create JDBC Statement obj
			   Statement st=con.createStatement();

			   //prepare SQL query
			               // SELECT ENAME,EMPNO,JOB,DEPTNO,SAL  FROM EMP WHERE SAL>=1000  AND SAL<=3000
			    String query="SELECT ENAME,EMPNO,JOB,DEPTNO,SAL  FROM EMP WHERE SAL>="+startSal+"AND SAL<="+endSal;
				  System.out.println(query);

				  //send and execute the SQL Query in Db s/w
				  ResultSet rs=st.executeQuery(query);


				  //process the ResultSet obj
				  boolean isRsEmpty=false;
				  while(rs.next()){
                      System.out.println(rs.getString(1)+"  "+rs.getInt(2)+"  "+rs.getString(3)+"  "+rs.getInt(4)+" "+rs.getFloat(5));
					 isRsEmpty=true;
				  }
				 
				 if(isRsEmpty)
				   System.out.println(" records are found and displayed");
				  else
					  System.out.println("no records are found");
				  
					 


				  //close the jdbc objs
				   rs.close();
				   st.close();
				   con.close();

	}//main
}//class
// cmd> javac    SelectTest2.java
//cmd> java SelectTest2
