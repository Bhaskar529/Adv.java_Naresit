//TestApp.java

class  Test
{
	static{
		System.out.println("Test: static block");
	}

	public Test(){
		System.out.println("Test: 0-param constructor");
	}
}//class

class  Demo
{
	static{
		System.out.println("Demo: static block");
	}

	public Demo(){
		System.out.println("Demo: 0-param constructor");
	}
}//class

public  class   TestApp
{
	static {
        System.out.println("TestApp: static block");
	}
	public static void main(String[] args) throws Exception
	{
		System.out.println("TestApp: start of main(-) method");
          Test t1=new Test();
		  Test t2=new Test();
           
		   Class.forName("Demo1");
		   Class.forName("Demo");
		     Class.forName("Test");
       System.out.println("TestApp: end of main(-) method");

	}
}
