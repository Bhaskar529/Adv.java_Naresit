//App2.java

public interface App2
{  
	  
	  public static void main(String args[]){
              int x=10;
			  System.out.println("square value ::"+(x*x));
	  }

}