//App1.java

public enum App1
{  
	  a;
	  public static void main(String args[]){
              int x=10;
			  System.out.println("square value ::"+(x*x));
	  }

}