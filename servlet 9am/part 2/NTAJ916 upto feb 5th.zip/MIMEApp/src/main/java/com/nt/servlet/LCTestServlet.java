//LCTestServlet.java
package com.nt.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebInitParam;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "/lcurl",loadOnStartup = 1,name="lc",
                            initParams = {@WebInitParam(name = "p1",value="val11"),@WebInitParam(name="dbuser",value="raja")})

//@WebServlet({ "/lcurl1","/lcurl2"})
//@WebServlet( value="/lcurl",name="lc1")
public  class LCTestServlet extends HttpServlet {
	static {
		System.out.println("LCTestServlet:static block()");
	}
	
	public LCTestServlet() {
		System.out.println("LCTestServlet:: 0-param constructor");
		}
	
		
	    ServletConfig cg;
		/*@Override
		public void init(ServletConfig cg) throws ServletException {
			this.cg=cg;
			System.out.println("LCTestServlet.init(ServletConfig cg)(1 param)");
			System.out.println(cg.getInitParameter("p1"));
		}*/
		
		public void init() {
			System.out.println("LCTestServlet.init() (no param init method)");
			ServletConfig cg=getServletConfig();
			System.out.println("from init::"+cg.getInitParameter("p1")+"  "+cg.getInitParameter("dbuser"));
		}
	
		@Override
		public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
			System.out.println("LCTestServlet.doGet(-,-)");
			//get PrintWriter object
			PrintWriter pw=res.getWriter();
			//set response content type
			res.setContentType("text/html");
			//write output to response obj
			Date d=new Date();
			pw.println("<h1> Date and time is :::"+d+"</h1>");
			
			
			ServletConfig cg=getServletConfig();
			System.out.println("from service:"+cg.getInitParameter("p1"));
			
			//close stream
			pw.close();
			
		}
	
	
	@Override
	public void destroy() {
		System.out.println("LCTestServlet.destroy()");
	}
	
	

}
